Perfil nunca é excluído
