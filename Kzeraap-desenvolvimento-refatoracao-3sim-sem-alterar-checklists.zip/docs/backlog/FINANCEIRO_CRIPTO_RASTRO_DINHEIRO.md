Prioridade: média/alta
