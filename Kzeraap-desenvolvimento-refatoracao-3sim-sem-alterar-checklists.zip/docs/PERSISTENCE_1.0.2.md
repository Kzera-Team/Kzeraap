Persistência Segura Base
