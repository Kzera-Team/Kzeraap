checkbox `Conhece Pessoalmente`
